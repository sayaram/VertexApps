﻿using GameEngine;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SFML.Graphics;
using SFML.System;
using SFML.Window;
using System.Reflection.Emit;

namespace MyGame
{
    class TRex : GameObject
    {
        private const float Speed = 0.3f;
        private const int FireDelay = 200;
        
        private const float Gravity = 0.3f; // Gravity constant, adjust as needed

               
        private readonly Sprite _sprite = new Sprite();
        public TRex()
        {
            _sprite.Texture = Game.GetTexture("Resources/Diano.png");
            _sprite.Position = new Vector2f(100, 510);
            SetCollisionCheckEnabled(true);
        }

         public override void Draw()
        {
            Game.RenderWindow.Draw(_sprite);
        }
        public override void Update(Time elapsed)
        {
            Vector2f pos = _sprite.Position;
            float x = pos.X;
            float y = pos.Y;

            int msElapsed = elapsed.AsMilliseconds();

            //// Existing movement code
            if (Keyboard.IsKeyPressed(Keyboard.Key.Up))
            {
                if (y >= 420)
                {
                    y -= Speed * msElapsed;
                }
            }
            else
            {
                y += Gravity * 10; //if not slowly move the player down
            }

            if (y > 510)
            {
                y = 510;
            }

            _sprite.Position = new Vector2f(x, y);

            PathBackground pathBackground = new PathBackground(new Vector2f(0, 550));
            Game.CurrentScene.AddGameObject(pathBackground);

            GameScene scene = (GameScene)Game.CurrentScene;
            scene.IncreaseScore();
        }

        public override FloatRect GetCollisionRect()
        {
            return _sprite.GetGlobalBounds();
        }

        public override void HandleCollision(GameObject otherGameObject)
        {
            if (otherGameObject.HasTag("tree")) 
            {
                GameScene scene = (GameScene)Game.CurrentScene; //Gameover
                scene.HandleGameOver();
                MakeDead();
            }
        }

    }
}
