# Resources for My Game

Place artwork and other files needed by your game in this directory. Examples include:

- Images
- Sprites
- Backgrounds
- Sounds

