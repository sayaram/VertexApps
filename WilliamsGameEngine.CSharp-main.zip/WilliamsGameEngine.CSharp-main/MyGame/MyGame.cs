﻿using GameEngine;
using System;
using System.Security.Cryptography.X509Certificates;

namespace MyGame
{
    public static class MyGame
    {
        private const int WindowWidth = 800;
        private const int WindowHeight = 600;
        
        private const string WindowTitle = "TRex Jump";

        private static void Main(string[] args)
        {
            // Initialize the game.
            Game.Initialize(WindowWidth, WindowHeight, WindowTitle);
            
            // Create our scene.
            GameScene scene = new GameScene();
            Game.SetScene(scene);

            // Run the game loop.
            Game.Run();
        }
    }
}