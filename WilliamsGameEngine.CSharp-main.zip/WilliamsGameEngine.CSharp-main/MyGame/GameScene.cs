﻿using GameEngine;
using SFML.System;

namespace MyGame
{
    class GameScene : Scene
    {
       
        private int _score;
        public GameScene()
        {
            TRex trex = new TRex(); // Use the public constructor of the Ship class
            AddGameObject(trex);

            TreeSpawner treeSpawner = new TreeSpawner();
            AddGameObject(treeSpawner);

            Score score = new Score(new Vector2f(10.0f, 10.0f));
            AddGameObject(score);
        }
        public int GetScore()
        {
            return _score;
        }
        public void IncreaseScore()
        {
            ++_score;
        }

        
        public void HandleGameOver()
        {
             GameOverScene gameOverScene = new GameOverScene(_score);
            Game.SetScene(gameOverScene);
         }
    }
  
}