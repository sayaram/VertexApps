﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GameEngine;
using SFML.Graphics;
using SFML.System;

namespace MyGame
{
    class TreeSpawner : GameObject
    {
        private int SpawnDelay = 1000;
        private int _timer;
   
        public override void Update(Time elapsed)
        {
            int msElapsed = elapsed.AsMilliseconds();
            _timer -= msElapsed;
            if (_timer <= 0)
            {
                _timer = SpawnDelay;
                Vector2u size = Game.RenderWindow.Size;
              
                Random rnd = new Random();
                
                if (rnd.Next() % 2 == 0)
                {
                    float meteorX = size.X + 100;
                     float meteorY = 510;

                    TreeOne treeone = new TreeOne(new Vector2f(meteorX, meteorY));
                    Game.CurrentScene.AddGameObject(treeone);
                }
                else
                {
                    float meteorX = size.X + 100;
                    float meteorY = 520;

                    TreeTwo treetwo = new TreeTwo(new Vector2f(meteorX, meteorY));
                    Game.CurrentScene.AddGameObject(treetwo);
                }
                if (SpawnDelay > 500)
                {
                     SpawnDelay --;
                }
                 
              }
        }
    }
}
